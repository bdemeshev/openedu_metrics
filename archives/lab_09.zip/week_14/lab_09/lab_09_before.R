# Esli russkie bukvi prevratilitis v krakozyabry,
# to File - Reopen with encoding... - UTF-8 - Set as default - OK

# lab 09

library("dplyr") # манипуляции с данными
library("caret") # стандартизованный подход к регрессионным и классификационным моделям
library("AER") # инструментальные переменные 
library("ggplot2") # графики
library("sandwich") # робастные стандартные ошибки
library("ivpack") # дополнительные плющки для инструментальных переменных
library("memisc") # табличка mtable 