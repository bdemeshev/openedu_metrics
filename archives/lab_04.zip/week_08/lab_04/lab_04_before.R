# ESLI RUSSKIE BUKVI NE VIDNI --->
# File -- Reopen with encoding --- utf8 --- set as default --- ok


library("HSAUR") # из этого пакета возьмем набор данных по семиборью
library("dplyr") # манипуляции с данными
library("psych") # описательные статистики
library("lmtest") # тесты для линейных моделей
library("glmnet") # LASSO + ridge
library("ggplot2") # графики
library("car") # vif
